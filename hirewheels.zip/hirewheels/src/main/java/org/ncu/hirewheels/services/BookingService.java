package org.ncu.hirewheels.services;

import org.ncu.hirewheels.entities.Booking;

public interface BookingService {
    Booking addBooking(Booking booking);
}
